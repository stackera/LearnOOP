
package net.learnbyproject;

import java.util.Scanner;

public class Menu {
    
}
