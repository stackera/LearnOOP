
package net.learnbyproject.businesslogic;


public interface BookInterface {

}
