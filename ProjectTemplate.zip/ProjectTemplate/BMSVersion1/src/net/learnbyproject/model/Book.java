
package net.learnbyproject.model;


public class Book {

}
