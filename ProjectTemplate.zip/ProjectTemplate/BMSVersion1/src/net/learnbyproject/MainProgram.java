
package net.learnbyproject;

import net.learnbyproject.businesslogic.BookListWithArray;
import net.learnbyproject.businesslogic.BookInterface;


public class MainProgram {
    public static void main(String[] args) {
        
    }
}
