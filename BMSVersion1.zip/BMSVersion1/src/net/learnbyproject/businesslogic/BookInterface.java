
package net.learnbyproject.businesslogic;


public interface BookInterface {
    void add();
    void remove();
    void update();
    void print();
}
