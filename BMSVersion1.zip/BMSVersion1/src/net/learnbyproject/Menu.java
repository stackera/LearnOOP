
package net.learnbyproject;

import java.util.Scanner;

public class Menu {
    private String[] menuItems;
    private int count = 0; // current number of menuItems
    
    public Menu(int size) {
        menuItems = new String[size];
    }
    
    public void addNewMenuItem(String item) {
        if (count < menuItems.length) {
            menuItems[count++] = item;
        }
    }
    
    public int getUserSelection() {
        System.out.println("THE BOOK TIGER COMPANY");
        int result = 0;
        if (count > 0) { // print out menuItems
            for (int i = 0; i < count; i++) {
                System.out.println((i + 1) + "-" + menuItems[i]);
            }
            System.out.print("Please select an operation: ");
            Scanner sc = new Scanner(System.in);
            result = sc.nextInt();
        }
        return result;
    }
}
