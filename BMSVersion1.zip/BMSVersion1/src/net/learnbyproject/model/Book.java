
package net.learnbyproject.model;


public class Book {
    private String isbn;
    private double price;
    private int publishedYear;

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getPublishedYear() {
        return publishedYear;
    }

    public void setPublishedYear(int publishedYear) {
        this.publishedYear = publishedYear;
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    @Override
    public String toString() {
        return this.isbn + " | " + this.price + " | " + this.publishedYear;
    }  
}
