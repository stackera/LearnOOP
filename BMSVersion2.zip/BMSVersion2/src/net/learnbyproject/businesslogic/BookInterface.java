
package net.learnbyproject.businesslogic;

import java.io.IOException;


public interface BookInterface {
    void add() throws Exception;
    void remove() throws Exception;
    void update() throws Exception;
    void print();
    void readDataFromFile() throws IOException;
    void saveToFile() throws IOException;
}
