package net.learnbyproject.businesslogic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.learnbyproject.model.Book;
import java.util.Scanner;

public class BookListWithCollection implements BookInterface {

    private List<Book> list = null;
    private String fileName = "data.csv";

    public BookListWithCollection() {
        list = new ArrayList();
    }

    int find(String isbn) {
        for (int i = 0; i < list.size(); i++) {
            if (isbn.equals(list.get(i).getIsbn())) {
                return i;
            }
        }
        return -1;
    }

    boolean checkISBN(String isbn) {
        String pattern = "ISBN-\\d{3}-\\d{4}";
        return isbn.matches(pattern);
    }

    boolean checkPublishedYear(int publishedYear) {
        String pattern = "\\d{4}";
        String year = String.valueOf(publishedYear);

        return year.matches(pattern);
    }

    boolean checkPrice(double price) {
        return price >= 0;
    }

    @Override
    public void add() throws Exception {
        String isbn;
        double price = 0;
        int publishedYear = 0;
        Scanner sc = new Scanner(System.in);

        boolean flag;
        do {
            System.out.print("Enter book ISBN: ");
            isbn = sc.next();
            flag = checkISBN(isbn);
            if (!flag) {
                System.out.println("Invalid ISBN");
            }
        } while (!flag);

        /* Check if isbn is already in the list*/
        int index = find(isbn);
        if (index >= 0) {
            System.out.println("ISBN alrady exists. Please try another!");
            return;
        }

        do {
            System.out.print("Enter book price: ");
            price = sc.nextDouble();
            flag = checkPrice(price);
            if (!flag) {
                System.out.println("Invalid book price");
            }
        } while (!flag);

        do {
            System.out.print("Enter published year: ");
            publishedYear = sc.nextInt();
            flag = checkPublishedYear(publishedYear);
            if (!flag) {
                System.out.println("Invalid published ");
            }
        } while (!flag);

        Book b = new Book();
        b.setIsbn(isbn);
        b.setPrice(price);
        b.setPublishedYear(publishedYear);

        list.add(b);
        System.out.println("New book has been added.");
    }

    @Override
    public void remove() throws Exception {
        String removedISBN;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the isbn of the book you wish to remove: ");
        removedISBN = sc.nextLine().trim();
        int pos = find(removedISBN);
        if (pos < 0) {
            System.out.println("This book does not exist.");
        } else {
            list.remove(pos);
            System.out.println("The book with the ISBN: " + removedISBN + " has been removed");
        }
    }

    @Override
    public void update() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the ISBN of the book to update: ");
        String isbn = sc.nextLine();
        int pos = find(isbn);
        if (pos < 0) {
            System.out.println("This book does not exist.");
        } else {
            System.out.print("Enter the new price: ");
            double newPrice = sc.nextDouble();
            System.out.print("Enter the new published year: ");
            int newPublishedYear = sc.nextInt();
            list.get(pos).setPrice(newPrice);
            list.get(pos).setPublishedYear(newPublishedYear);
            System.out.println("The book with the ISBN: " + isbn + " has been updated");
        }
    }

    @Override
    public void print() {
        if (list.isEmpty()) {
            System.out.println("There is no books in the system");
            return;
        }
        //Sort book list
        Collections.sort(list);
        System.out.println("LIST OF BOOKS:");
        System.out.format("%10s\t|\t%5s\t|\t%5s\n", "ISBN", "Price", "Published Year");

        for (int i = 0; i < list.size(); i++) {
            Book b = list.get(i);
            System.out.format("%10s\t|\t%5.2f\t|\t%5d\n", b.getIsbn(),
                    b.getPrice(), b.getPublishedYear());
        }
    }

    @Override
    public void readDataFromFile() throws IOException {
        
        String line = "";
        File file = new File(fileName);
        if (!file.exists()) {
            return;
        }
        try (FileReader fr = new FileReader(file);
             BufferedReader br = new BufferedReader(fr)) {
            while ((line = br.readLine()) != null) {
                String[] bookInfo = line.split(",");
                Book b = new Book();
                b.setIsbn(bookInfo[0]);
                b.setPrice(Double.parseDouble(bookInfo[1]));
                b.setPublishedYear(Integer.parseInt(bookInfo[2]));
                list.add(b);
            }
            System.out.println(list.size() + " books loaded from file.");
        } 
    }

    @Override
    public void saveToFile() throws IOException {
        try (PrintWriter pw = new PrintWriter(fileName)){
            for (Book book : list) {
                String line = String.format("%s,%f,%d", 
                        book.getIsbn(), book.getPrice(), book.getPublishedYear());
                pw.println(line);
            }
            System.out.println("All data has been saved");
        }
    }   
}
