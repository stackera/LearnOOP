package net.learnbyproject;

import net.learnbyproject.businesslogic.BookListWithArray;
import net.learnbyproject.businesslogic.BookInterface;
import net.learnbyproject.businesslogic.BookListWithCollection;

public class MainProgram {

    public static void main(String[] args) {
        Menu menu = new Menu(6);
        menu.addNewMenuItem("Add new book");
        menu.addNewMenuItem("Remove a book");
        menu.addNewMenuItem("Update a book");
        menu.addNewMenuItem("List all books");
        menu.addNewMenuItem("Quit");

//        BookInterface list = new BookListWithArray();
        BookInterface list = new BookListWithCollection();

        int choice;
        boolean flag = true;
        try {
            list.readDataFromFile();
            do {
                choice = menu.getUserSelection();
                switch (choice) {
                    case 1:
                        list.add();
                        break;
                    case 2:
                        list.remove();
                        break;
                    case 3:
                        list.update();
                        break;
                    case 4:
                        list.print();
                        break;
                    case 5:
                        list.saveToFile();
                        flag = false;
                        break;
                    default:
                        System.out.println("Invalid menu option!");
                }
            } while (flag);
        } catch (Exception e) {
            System.out.println("There was issue: " + e.getMessage());
        }

    }
}
